__init__.py is to indidcate that directory shall be used as import directory
guic.py is the Graphical User Interface Controller source file
guial.py is the Graphical User Interface Abstraction Layer Class

-Worked on create user screen